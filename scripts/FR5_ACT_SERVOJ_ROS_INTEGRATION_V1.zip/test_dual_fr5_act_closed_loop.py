#!/usr/bin/env python3
"""Live, supervised ACT -> ROS -> FAIRINO ServoJ *experimental* test.

No Robot.RPC() connection is opened here; existing fairino_ctrl_1_node
owns the SDK. This process only receives ROS joint/image observations and
publishes six-joint targets in RADIANS to /fairino_1/act_servoj/target.

Default is PREVIEW ONLY. --execute and explicit terminal confirmation are
required to request real motion. This does NOT certify collision safety.
"""
import argparse
import json
import sys
import time

import numpy as np
import rclpy
import torch
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from sensor_msgs.msg import Image, JointState
from std_msgs.msg import Bool, String

from robo_manip_baselines.common import denormalize_data
from test_dual_fr5_act import load_policy, prepare_state, prepare_images

PREFIX = '/fairino_1/act_servoj'
SOURCES = {
    'fr1': '/fairino_1/joint_states',
    'fr2': '/fairino_2/joint_states',
    'front': '/camera_d405_1/color/image_rect_raw',
    'hand': '/camera_d405_2/color/image_rect_raw',
}


def joint_rad(msg):
    names = [f'joint_{n}' for n in range(1, 7)]
    if len(msg.name) != len(set(msg.name)) or len(msg.position) != len(msg.name):
        raise ValueError('Duplicate or mismatched joint names/positions')
    mapping = dict(zip(msg.name, msg.position))
    if not all(name in mapping for name in names):
        raise ValueError(f'Joint names must include {names}')
    q = np.asarray([mapping[name] for name in names], dtype=np.float64)
    if q.shape != (6,) or not np.isfinite(q).all():
        raise ValueError('Invalid joint positions')
    return q


def image_rgb(msg):
    if msg.encoding not in ('rgb8', 'bgr8'):
        raise ValueError(f'Expected rgb8/bgr8, got {msg.encoding!r}')
    if msg.width <= 0 or msg.height <= 0 or msg.step < msg.width * 3:
        raise ValueError('Invalid image dimensions/stride')
    raw = np.frombuffer(msg.data, dtype=np.uint8)
    expected = msg.height * msg.step
    if raw.size != expected:
        raise ValueError(f'Image byte count {raw.size} != {expected}')
    rgb = raw.reshape(msg.height, msg.step)[:, :msg.width * 3]
    rgb = rgb.reshape(msg.height, msg.width, 3)
    if msg.encoding == 'bgr8':
        return rgb[:, :, ::-1].copy()
    return rgb.copy()


class Observations(Node):
    def __init__(self):
        super().__init__('act_fr5_1_live_client')
        self.data = {}
        self.arrivals = {}
        self.seq = {k: 0 for k in SOURCES}
        self.status = None
        self.status_at = 0.0
        qos = QoSProfile(
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
        )
        self.subscribers = []
        for key in ('fr1', 'fr2'):
            self.subscribers.append(self.create_subscription(
                JointState, SOURCES[key], lambda msg, k=key: self._joint(k, msg), qos))
        for key in ('front', 'hand'):
            self.subscribers.append(self.create_subscription(
                Image, SOURCES[key], lambda msg, k=key: self._image(k, msg), qos))
        self.target_pub = self.create_publisher(JointState, PREFIX + '/target', 10)
        self.arm_pub = self.create_publisher(Bool, PREFIX + '/arm', 10)
        self.stop_pub = self.create_publisher(Bool, PREFIX + '/stop', 10)
        self.status_sub = self.create_subscription(
            String, PREFIX + '/status', self._status,
            QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                       durability=DurabilityPolicy.TRANSIENT_LOCAL))

    def _joint(self, key, msg):
        try:
            self.data[key] = joint_rad(msg)
            self.arrivals[key] = time.monotonic()
            self.seq[key] += 1
        except Exception as exc:
            self.get_logger().error(f'{key} invalid joint feedback: {exc}')

    def _image(self, key, msg):
        try:
            self.data[key] = image_rgb(msg)
            self.arrivals[key] = time.monotonic()
            self.seq[key] += 1
        except Exception as exc:
            self.get_logger().error(f'{key} camera frame invalid: {exc}')

    def _status(self, msg):
        try:
            self.status = json.loads(msg.data)
            self.status_at = time.monotonic()
            print('[SERVO STATUS]', msg.data, flush=True)
        except (ValueError, TypeError):
            self.get_logger().error(f'Malformed bridge status: {msg.data}')

    def snapshot(self, since=None, max_age=0.30, max_spread=0.12):
        if len(self.data) != len(SOURCES):
            return None
        if since is not None and any(self.seq[k] <= since[k] for k in SOURCES):
            return None
        now = time.monotonic()
        times = list(self.arrivals.values())
        if len(times) != len(SOURCES):
            return None
        if max(now - t for t in times) > max_age:
            return None
        if max(times) - min(times) > max_spread:
            return None
        q = np.concatenate((self.data['fr1'], self.data['fr2']))
        obs = {'joint_pos': q.copy()}
        info = {'rgb_images': {
            'front': self.data['front'].copy(),
            'hand': self.data['hand'].copy(),
        }}
        return obs, info, dict(self.seq)

    def wait_observation(self, since=None, timeout=6.0):
        deadline = time.monotonic() + timeout
        while rclpy.ok() and time.monotonic() < deadline:
            rclpy.spin_once(self, timeout_sec=0.015)
            snap = self.snapshot(since=since)
            if snap is not None:
                return snap
        raise RuntimeError('No new, suitably synchronized camera + joint observations')

    def send_target(self, q_rad):
        q = np.asarray(q_rad, dtype=np.float64)
        if q.shape != (6,) or not np.isfinite(q).all():
            raise ValueError('Invalid six-joint ACT command')
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.name = [f'joint_{i}' for i in range(1, 7)]
        msg.position = q.tolist()  # ALWAYS RADIANS on the ROS topic
        self.target_pub.publish(msg)

    def arm(self):
        msg = Bool(); msg.data = True
        self.arm_pub.publish(msg)

    def stop(self):
        msg = Bool(); msg.data = True
        for _ in range(5):
            self.stop_pub.publish(msg)
            rclpy.spin_once(self, timeout_sec=0.04)


def inference(policy, meta, device, obs, info):
    q_t, measured = prepare_state(obs, meta, device)
    rgb_t = prepare_images(info, meta, device)
    with torch.inference_mode():
        chunk_t = policy(q_t, rgb_t)
    chunk = chunk_t[0].detach().cpu().numpy()
    if chunk.ndim != 2 or chunk.shape[1] != 12:
        raise RuntimeError(f'Unexpected ACT output shape {chunk.shape}')
    result = np.asarray([denormalize_data(a, meta['action']) for a in chunk], dtype=np.float64)
    if result.shape != chunk.shape or not np.isfinite(result).all():
        raise RuntimeError('ACT prediction contained NaN/Inf')
    return result, measured


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--checkpoint', required=True)
    ap.add_argument('--device', choices=['cuda', 'cpu'], default='cuda')
    ap.add_argument('--execute', action='store_true', help='Enable one timed real-hardware session')
    ap.add_argument('--steps', type=int, default=90)
    ap.add_argument('--hz', type=float, default=15.0)
    ap.add_argument('--max-duration', type=float, default=9.0)
    args = ap.parse_args()
    if args.steps < 1 or not (1.0 <= args.hz <= 15.0) or not (0 < args.max_duration <= 10.0):
        ap.error('Require steps>=1, 1<=hz<=15, 0<max-duration<=10s')
    if args.device == 'cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable (use --device cpu)')
    device = torch.device(args.device)
    policy, meta = load_policy(args.checkpoint, device)
    skip = int(meta['data']['skip'])
    if skip < 1 or skip > int(meta['data']['chunk_size']):
        raise RuntimeError(f'Unexpected ACT skip/chunk size: {skip}')
    rclpy.init()
    node = Observations()
    armed = False
    try:
        print('\nWaiting for real cameras and BOTH FR5 joint-state topics...', flush=True)
        obs, info, seq = node.wait_observation(timeout=12.0)
        preview_chunk, measured = inference(policy, meta, device, obs, info)
        proposed = np.rad2deg(preview_chunk[0, :6])
        current = np.rad2deg(measured[:6])
        print('\n=== LIVE ACT PREVIEW, FR5 #1 ONLY ===')
        print('Measured six joints (deg):', np.round(current, 3))
        print('ACT first target (deg): ', np.round(proposed, 3))
        print('ACT delta (deg):        ', np.round(proposed - current, 3))
        print('ACT chunk:', preview_chunk.shape, 'skip:', skip)
        print('FR5 #2 is OBSERVED ONLY; no targets are published to it.')
        if node.status is None:
            print('Bridge status not yet received; ensure FR5 #1 controller was patched and launched.')
        if not args.execute:
            print('\nPREVIEW ONLY. No servo targets or arm commands sent.')
            return
        if node.status is None or node.status.get('ip') != '192.168.58.2' or node.status.get('state') != 'idle':
            raise RuntimeError(f'Expected IDLE hardware-enabled FR5#1 bridge; status={node.status}')
        print('\nWARNING: This is experimental physical ACT motion. No collision checking,')
        print('no gripper command, and the SDK may block on socket retries.')
        print('Verify swept-path clearance, active independent physical E-stop,')
        print('no existing controller fault, and no competing robot motion source.')
        confirm = input('Type START ACT FR5 1 to arm and run this bounded session: ').strip()
        if confirm != 'START ACT FR5 1':
            print('Cancelled without motion.')
            return
        # Obtain fresh observations after operator confirmation.
        obs, info, seq = node.wait_observation(since=seq, timeout=4.0)
        fresh_chunk, fresh_q = inference(policy, meta, device, obs, info)
        revised = np.rad2deg(fresh_chunk[0, :6])
        if np.max(np.abs(revised - proposed)) > 1.0:
            raise RuntimeError('ACT first target changed >1 deg since preview; run preview again')
        print('Fresh ACT target (deg):', np.round(revised, 3))
        node.arm()
        armed = True
        deadline = time.monotonic() + 2.0
        while time.monotonic() < deadline:
            rclpy.spin_once(node, timeout_sec=0.03)
            if node.status is not None and node.status.get('state') in ('armed', 'running'):
                break
            if node.status is not None and node.status.get('state') in ('fault', 'disabled'):
                raise RuntimeError(f'Servo bridge refused to arm: {node.status}')
        else:
            raise RuntimeError('No ARM acknowledgment from FR5 #1 bridge')
        period = 1.0 / args.hz
        started = time.monotonic()
        next_tick = started
        action_chunk = fresh_chunk
        for step in range(args.steps):
            if time.monotonic() - started >= args.max_duration:
                print('ACT session duration limit reached')
                break
            # The first action was explicitly previewed; after this, reobserve.
            if step == 0:
                current_obs, current_info, current_seq = obs, info, seq
            else:
                current_obs, current_info, current_seq = node.wait_observation(since=seq, timeout=0.30)
                seq = current_seq
            if step > 0 and step % skip == 0:
                t0 = time.perf_counter()
                action_chunk, _ = inference(policy, meta, device, current_obs, current_info)
                latency = (time.perf_counter() - t0) * 1000
                print(f'ACT inference step={step}: {latency:.1f} ms')
            index = step % skip
            action = action_chunk[index]
            q_current = np.rad2deg(np.asarray(current_obs['joint_pos'][:6]))
            q_target = np.rad2deg(action[:6])
            print(f'step={step+1:03d} delta_deg={np.round(q_target - q_current, 2)}', flush=True)
            if np.max(np.abs(q_target - q_current)) > 12.0:
                raise RuntimeError('ACT target jumps >12deg from observed joints: abort')
            node.send_target(action[:6])
            deadline_tick = next_tick + period
            while time.monotonic() < deadline_tick:
                rclpy.spin_once(node, timeout_sec=min(0.008, max(0, deadline_tick - time.monotonic())))
                if node.status is not None and node.status.get('state') == 'fault':
                    raise RuntimeError(f'Servo bridge fault: {node.status}')
            next_tick = deadline_tick
            # Do not publish bursts to catch up. If inference is slow, the
            # next tick starts from the present time, while the controller's
            # independent target-age watchdog still enforces freshness.
            if time.monotonic() > next_tick:
                print(f'[TIMING] ACT behind desired {args.hz:.1f} Hz; running at measured rate', flush=True)
                next_tick = time.monotonic()
        print('ACT bounded session finished; requesting servo end.')
    finally:
        if armed:
            print('Sending /stop and awaiting bridge status...')
            node.stop()
            end_deadline = time.monotonic() + 3.0
            while time.monotonic() < end_deadline:
                rclpy.spin_once(node, timeout_sec=0.08)
                if node.status is not None and node.status.get('state') in ('stopped', 'fault'):
                    break
            print('Final bridge state:', node.status)
            if node.status is None or node.status.get('state') not in ('stopped', 'fault'):
                print('WARNING: end of servo session NOT confirmed. Use physical stop if necessary.')
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('Interrupted by operator. Confirm robot is stopped.')
        sys.exit(130)
