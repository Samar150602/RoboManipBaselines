FR5 #1 ACT CLOSED-LOOP EXPERIMENT (ROS2 Humble)
=================================================
Files:
  fairino_act_servoj_bridge.py           SDK-owning worker inside existing FAIRINO controller
  install_fr5_act_servoj.py              preview/apply patches with dated backups
  test_dual_fr5_act_closed_loop.py       live 2-camera + 12-joint ACT client

Purpose: short bounded experimental FR5#1 arm-motion trial. No gripper command.
FR5#2 is observed but receives NO target commands.
This is NOT a production robot safety controller. No trajectory collision checking or
safety-rated remote stop. An active independent physical emergency stop, verified
workspace clearance, no personnel in the work envelope, and robot safety configuration
are REQUIRED before a hardware trial.

INSTALL (run from PC with source files):
  1. Copy the three Python scripts to ~/Downloads/ .
  2. Stop ROS controller processes for FR5#1 and FR5#2 before patch/build.
  3. python3 ~/Downloads/install_fr5_act_servoj.py
     -> inspect diff; no files are changed.
  4. python3 ~/Downloads/install_fr5_act_servoj.py --apply
     -> dated backups; edits node and FR5#1 & dual launch when present.
  5. cd ~/Downloads/ros2_ws_260827
     source /opt/ros/humble/setup.bash
     colcon build --packages-select fairino_ctrl --symlink-install
     source install/setup.bash
  6. Copy test_dual_fr5_act_closed_loop.py to
     ~/RMB_ws/src/RoboManipBaselines/scripts/

IMPORTANT: The patch leaves enable_act_servoj=False in launch files.
You MUST review the node patch and run the non-actuating preview first. To permit
an explicitly supervised trial, change enable_act_servoj to True only for FR5#1
in the launch file you're actually using. Do not enable it on FR5#2.

START ROS: Launch the usual FAIRINO controller(s), RealSense RGB nodes, and
joint-state publishers. Do not run a standalone Robot.RPC or MoveJ client.
Ensure /fairino_1/act_servoj/status, /target, /arm, /stop exist and NO
/fairino_2/act_servoj target/arm interface is created by this bridge.
The bridge's /status field should show idle when enabled, disabled otherwise.

PREVIEW ONLY (no arm request):
  cd ~/RMB_ws/src/RoboManipBaselines
  source /opt/ros/humble/setup.bash
  source ~/Downloads/ros2_ws_260827/install/setup.bash
  [activate the SAME Python venv used for your successful ACT shadow test]
  python3 scripts/test_dual_fr5_act_closed_loop.py \
    --checkpoint /FULL/PATH/TO/policy_best.ckpt --steps 90

SUPERVISED HARDWARE RUN (after verifying faults cleared, service uniqueness,
ROS FR5#1 joint-to-SDK mapping, physical E-stop and trajectory clearance):
  python3 scripts/test_dual_fr5_act_closed_loop.py \
    --checkpoint /FULL/PATH/TO/policy_best.ckpt --execute \
    --steps 90 --max-duration 9 --hz 15
  Read preview, type START ACT FR5 1 to arm.
  The bridge streams using nominal 8ms ServoJ commands, with position,
  velocity, acceleration, tracking, feedback and target watchdog checks.
  Defaults: 5deg/s per joint, 25deg/s^2, max 12deg target gap, 9s client.
  Reject/fault means do not retry until robot and controller status checked.

To request an ordinary software stop from another ROS terminal:
  ros2 topic pub --once /fairino_1/act_servoj/stop std_msgs/msg/Bool '{data: true}'
THIS IS NOT SAFETY-RATED: physical E-stop must remain available. SDK may retry
socket errors forever, and ROS /stop may not interrupt a blocking SDK call.

DISABLE: Set enable_act_servoj=False in the launch file and restart only after
verifying the robot is safe. The controller's original SDK startup code calls
ResetAllError(); do NOT restart merely to dismiss a fault.

This test evaluates only the learned FR5#1 arm trajectory. Because training has
no gripper state/action and FR5#2 is stationary, complete dual-arm autonomous
pick-and-place cannot be demonstrated by this experiment.
