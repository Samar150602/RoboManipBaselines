#!/usr/bin/env python3
"""Back up and patch the user's existing fairino_ctrl ROS2 source for the
FR5#1 experimental ACT ServoJ bridge. Does NOT run any hardware command.

Usage: python3 install_fr5_act_servoj.py --apply
The script must be kept alongside fairino_act_servoj_bridge.py.
"""
import argparse
import datetime
import difflib
import re
import shutil
from pathlib import Path

BASE = (Path.home() / 'Downloads/ros2_ws_260827/src/fairino_ctrl/fairino_ctrl')
NODE = BASE / 'fairino_ctrl/fairino_ctrl_node.py'
BRIDGE = BASE / 'fairino_ctrl/fairino_act_servoj_bridge.py'
LAUNCH = BASE / 'launch/fairino_ctrl_1-launch.py'
DUAL_LAUNCH = BASE / 'launch/fairino_ctrl_dual-launch.py'


def patch_node(source):
    source = source.replace(
        'from .fairino_python_sdk import Robot',
        'from .fairino_python_sdk import Robot\nfrom .fairino_act_servoj_bridge import ActServoJBridge', 1)
    if 'from .fairino_act_servoj_bridge import ActServoJBridge' not in source:
        raise ValueError('Cannot find Robot SDK import in controller')

    if 'self.act_servoj = (' not in source:
        m = re.search(r'^(\s*self\.servo_start_flag\s*=\s*False[^\n]*)$', source, re.M)
        if m is None:
            raise ValueError('Cannot find self.servo_start_flag = False in controller')
        insert = '''\n        # ACT ServoJ worker exists ONLY on FR5 #1. Second arm does not subscribe.
        self.act_servoj = (
            ActServoJBridge(self, self.robot_RPC, self.robot_ip)
            if self.robot_ip == "192.168.58.2" else None
        )'''
        source = source[:m.end()] + insert + source[m.end():]

    if 'ACT SERVOJ SERVICE ARBITRATION' not in source:
        signature = '    def movej_callback(self, request, response):\n'
        if source.count(signature) != 1:
            raise ValueError('Expected exactly one existing movej_callback: inspect manually')
        block = '''        # ACT SERVOJ SERVICE ARBITRATION: reject competing MoveJ while streaming.
        bridge = getattr(self, 'act_servoj', None)
        if bridge is not None and bridge.reserved:
            response.success = False
            response.error_code = -30
            response.message = 'MoveJ rejected: ServoJ session active or fault-latched'
            return response

'''
        source = source.replace(signature, signature + block, 1)

    if 'ACT SERVOJ REQUEST ARBITRATION' not in source:
        signature = '    def req_callback(self, rcv_msg):\n'
        if source.count(signature) != 1:
            raise ValueError('Expected exactly one req_callback')
        block = '''        # ACT SERVOJ REQUEST ARBITRATION:
        # Prevent other motion handlers using this SDK connection while streaming.
        if getattr(self, 'act_servoj', None) is not None and self.act_servoj.reserved:
            if rcv_msg.req_mode == rcv_msg.REQ_MODE_CHK_STOP:
                self.act_servoj.stop('Legacy ROS stop request')
                self.res_publish('ACT ServoJ software stop requested; verify stop')
            else:
                self.res_publish('[ERR] ACT ServoJ active; reject competing request')
            return

'''
        source = source.replace(signature, signature + block, 1)

    if 'ACT SERVOJ CLEAN SHUTDOWN' not in source:
        matches = list(re.finditer(r'^(?P<indent>[ \t]*)node\.close_rpc\(\)[ \t]*$', source, re.M))
        if len(matches) != 1:
            raise ValueError('Expected exactly one node.close_rpc() in main; inspect manually')
        block = '''    # ACT SERVOJ CLEAN SHUTDOWN: do not close SDK during an active servo worker.
    can_close = True
    if getattr(node, 'act_servoj', None) is not None:
        can_close = node.act_servoj.shutdown()
    if can_close:
        node.close_rpc()
    else:
        node.get_logger().error('Servo worker blocked: SDK close skipped; use physical E-stop if needed')'''
        indent = matches[0].group('indent')
        replacement = '\n'.join(indent + line[4:] if line.startswith('    ') else indent + line
                                for line in block.split('\n'))
        source = source[:matches[0].start()] + replacement + source[matches[0].end():]
    return source


def patch_launch(source):
    if 'enable_act_servoj' in source:
        return source
    pattern = r'([\"\']robot_ip[\"\']\s*:\s*[\"\']192\.168\.58\.2[\"\'])'
    modified, n = re.subn(pattern, r'\1, "enable_act_servoj": False', source, count=1)
    if n != 1:
        raise ValueError('Cannot find FR5 #1 robot_ip dictionary in launch file')
    return modified


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--apply', action='store_true', help='Actually patch files, default is diff preview')
    args = ap.parse_args()
    from_path = Path(__file__).resolve().parent / 'fairino_act_servoj_bridge.py'
    for path in (NODE, LAUNCH, from_path):
        if not path.exists():
            raise FileNotFoundError(path)
    old_node, old_launch = NODE.read_text(), LAUNCH.read_text()
    new_node, new_launch = patch_node(old_node), patch_launch(old_launch)
    files = [(NODE, old_node, new_node), (LAUNCH, old_launch, new_launch)]
    if DUAL_LAUNCH.exists():
        old_dual = DUAL_LAUNCH.read_text()
        new_dual = patch_launch(old_dual)
        files.append((DUAL_LAUNCH, old_dual, new_dual))
    compile(new_node, str(NODE), 'exec')
    compile(new_launch, str(LAUNCH), 'exec')
    if DUAL_LAUNCH.exists():
        compile(new_dual, str(DUAL_LAUNCH), 'exec')
    for path, old, new in files:
        print('\n###', path)
        print(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
                                           fromfile='before', tofile='after')) or '(already patched)')
    if not args.apply:
        print('\nDRY RUN: no files modified. Run with --apply to install.')
        return
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    for path, old, new in files:
        if new != old:
            backup = path.with_name(path.name + '.before_act_servoj_' + stamp)
            shutil.copy2(path, backup)
            print('Backup:', backup)
            path.write_text(new)
    shutil.copy2(from_path, BRIDGE)
    print('Installed bridge:', BRIDGE)
    print('Launch parameter enable_act_servoj=False by default; explicitly set True for a supervised hardware trial.')
    print('\nPATCHED ONLY: No robot commands were sent. Rebuild workspace, then verify topics.')


if __name__ == '__main__':
    main()
